/*
-- Query: SELECT * FROM assignment_schema.2014302580124_pet;

*/
INSERT INTO `2014302580124_pet` VALUES  (1,'dog','bone','water','ground','play'),(2,'cat','fish','milk','roof','hug'),(3,'turtle','fish,shrimp','sea water','sea water','bask'),(4,'parrot','nuts,seeds','water','tree','fly'),(5,'hamster','Sunflower seed','water','corner','eat'),(6,'squirrel','pine cone','water','tree hole,underground','play'),(7,'rabbit','carrot','water','grassland,underground','eat'),(8,'snake','mouse','water','hole','bask'),(9,'lizard','bug','water','tree','bask'),(10,'fish','aquatic plant','water','water','swim'),(11,'myna','earthworm','water','tree','fly'),(12,'canary','millet','water','tree','sing');
