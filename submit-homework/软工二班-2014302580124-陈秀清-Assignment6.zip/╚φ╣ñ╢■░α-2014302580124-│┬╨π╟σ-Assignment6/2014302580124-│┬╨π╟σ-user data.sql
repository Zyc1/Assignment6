/*
-- Query: SELECT * FROM assignment_schema.2014302580124_user;

*/
INSERT INTO `2014302580124_user` VALUES('12345','54321','12345','first','010-12345','12345@163.com','male'),('67890','09876','67890','second','010-67890','67890@163.com','female');