import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class DataBase2014302580124 {
	//public String url = "jdbc:mysql://localhost:3306/assignment6_schema";
	public String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
    public String driver = "com.mysql.jdbc.Driver";
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    String sql;
    PreparedStatement ps=null;
    //�������ݿ�
    public Connection getConn(){
    	 try {
             Class.forName(driver);
            // conn = (Connection) DriverManager.getConnection(url, "root", "cxqcxq1995");
             conn = (Connection) DriverManager.getConnection(url, "root", "12345");
             stmt = conn.createStatement();
                
             System.out.println("���ݿ����ӳɹ���");} catch (ClassNotFoundException e) {
                 System.out.println("���ݿ����������ڣ�");
                 System.out.println(e.toString());             
             } catch (SQLException e) {
                 System.out.println("SQL����");
                 System.out.println(e.toString());
             } finally {
                 }
    return conn;	
    }//end method getconn 
    //��ȡ������Ϣ
    public ArrayList<Pet2014302580124> readPetInfo() throws SQLException{
    	ArrayList<Pet2014302580124> petlist=new ArrayList<Pet2014302580124>();
        Connection conn=getConn();
        Statement stmt=null;
        ResultSet rs=null;
        stmt=conn.createStatement();
        rs=stmt.executeQuery("select*from 2014302580124_pet");
        while(rs.next()){
        	int id=rs.getInt(1);
        	String name=rs.getString(2);
        	String eat=rs.getString(3);
        	String drink=rs.getString(4);
        	String live=rs.getString(5);
        	String hobby=rs.getString(6);
        	petlist.add(new Pet2014302580124(id,name,eat,drink,live,hobby));
        }
        rs.close();
        conn.close();
    	return petlist;
    }//end method readPetInfo
    //��ȡ�û���Ϣ
    public ArrayList<Customer2014302580124> readUserInfo() throws SQLException{
    	ArrayList<Customer2014302580124> userlist=new ArrayList<Customer2014302580124>();
    	 Connection conn=getConn();
         Statement stmt=null;
         ResultSet rs=null;
         stmt=conn.createStatement();
         rs=stmt.executeQuery("select*from 2014302580124_user");
         while(rs.next()){
         	String id=rs.getString(1);
         	String password=rs.getString(2);
         	String account=rs.getString(3);
         	String name=rs.getString(4);
         	String phone=rs.getString(5);
         	String email=rs.getString(6);
         	String sex=rs.getString(7);
         	userlist.add(new Customer2014302580124(id,password,account,name,phone,email,sex));
         }
         rs.close();
         conn.close();
     	return userlist;
    }//end method readUserInfo
    
    //д�����û���Ϣ
   public void writeUserInfo(Customer2014302580124 user) throws SQLException{
	   Connection conn=getConn();
	   String sql;
	   PreparedStatement ps=null;
	   sql="insert into 2014302580124_user(id,passward,account,name,phone,email,sex)values('"+user.getId()+"','"+user.getPassword()+"','"+user.getAccount()+"','"+user.getName()+"','"+user.getPhone()+"','"+user.getEmail()+"','"+user.getSex()+"');";
	   ps=(PreparedStatement) conn.prepareStatement(sql);
	   ps.executeLargeUpdate(sql);
	   ps.close();
	   conn.close();
   }
}//end class Data2014302580124
