import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

public class GUIMain2014302580124 extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//��ǰ�û�
	Customer2014302580124 customer=new Customer2014302580124();
	ArrayList<Goods2014302580124> glist=new ArrayList<Goods2014302580124>();
	//��ǰ����
	Goods2014302580124 curgoods =new Goods2014302580124();
JPanel cardpanel=new JPanel();
//���忨Ƭ���ֶ���
CardLayout card=new CardLayout();
//�����������
mainPanel mainpanel=new mainPanel();
loginPanel loginpanel=new loginPanel();
registerPanel registerpanel=new registerPanel();

	public static void main(String[] args) {
		new GUIMain2014302580124();
		// TODO Auto-generated method stub
   	}//end main method
GUIMain2014302580124(){
	/*JFrame myframe=new JFrame("Pet Shop");
	//myframe.setTitle("Pet Shop");
	myframe.pack();
	myframe.setLocationRelativeTo(null);
	myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	myframe.setVisible(true);
	*/
	super("Pet Shop");
	setSize(800,500);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	setVisible(true);
	//����cardpanel������Ϊ��Ƭ����
	cardpanel.setLayout(card);
    /**
     * ��card�����������Ӹ�������
     */
	//������
cardpanel.add(mainpanel,"1");
	//��¼
cardpanel.add(loginpanel, "2");
	//ע��
cardpanel.add(registerpanel, "3");
	//��Ʒչʾ
//cardpanel.add(showpanel, "4");
	//��Ʒ��ϸ��Ϣ
//cardpanel.add(detailpanel, "5");
	//���ﳵ
//cardpanel.add(trolleypanel, "6");;
	//���嵱ǰ��������Ϊ��ǰ������������
	Container container=getContentPane();
	container.add(cardpanel);
	}//end constructor
//���������
class mainPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton login=new JButton("��¼");
	JButton register=new JButton("ע��");
	JPanel p1=new JPanel();
	
			public mainPanel(){
				p1.add(login,BorderLayout.NORTH);
				p1.add(register, BorderLayout.SOUTH);
				add(p1);
				login.addActionListener(new ActionListener(){
					
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						card.show(loginpanel.getParent(),"2");
					}

					} );
                register.addActionListener(new ActionListener(){

					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						card.show(registerpanel.getParent(),"3");
					}

					} );
				}
				
}//end class mainPanel
//��¼�������
class loginPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DataBase2014302580124 db;
	//private Customer2014302580124 customer;
	private JLabel l_id=new JLabel("ID:");
	private JLabel l_pass=new JLabel("Password:");
	private JPanel p1=new JPanel(),p2=new JPanel();
	private JTextArea t_id=new JTextArea(1,10);
	private JTextArea t_pass=new JTextArea(1,10);
	private JButton b_ok=new JButton("OK");
	private JPanel p_id=new JPanel();
	private JPanel p_pass=new JPanel();
	loginPanel(){
		p_id.add(l_id,BorderLayout.WEST);
		p_id.add(t_id, BorderLayout.EAST);
		p_pass.add(l_pass,BorderLayout.WEST);
		p_pass.add(t_pass, BorderLayout.EAST);
		p2.add(p_id, BorderLayout.NORTH);
		p2.add(p_pass, BorderLayout.SOUTH);
		p1.add(p2,BorderLayout.CENTER);
		p1.add(b_ok,BorderLayout.NORTH);
		add(p1);
		b_ok.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				db=new DataBase2014302580124();
				ArrayList<Customer2014302580124> clist;
				try {
					clist = db.readUserInfo();
					String id=t_id.getText();
				String password=t_pass.getText();
			//	System.out.println(clist.size());
				int i;
				for(i=0;i<clist.size();i++) {
				//	System.out.println(i+" "+clist.get(i).getId()+" "+clist.get(i).getPassword());
					if(id.equals(clist.get(i).getId())&&password.equals(clist.get(i).getPassword()))
					{ 
						customer=clist.get(i);//���µ�ǰ�û�
						//trolleyPanel trolleypanel=new trolleyPanel(customer);
						//cardpanel.add(trolleypanel,"6");
						//card.show(showpanel, "4");//��ת����Ʒչʾҳ��
						showPanel showpanel=new showPanel(customer);
						cardpanel.add(showpanel,"4");
						card.show(showpanel.getParent(),"4");
						break;
					}	//if 
					}//for
				//��ת��ע��ҳ��
				//System.out.println(i);
				if(i==clist.size()) card.show(registerpanel.getParent(), "3");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}	
		});
	}
}//end class loginPanel
//ע�����
class registerPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel p1=new JPanel();
	private DataBase2014302580124 db=new DataBase2014302580124();
	private JLabel l_id=new JLabel("ID:");
	private JLabel l_pass=new JLabel("Password:");
	private JLabel l_name=new JLabel("Name:");
	private JLabel l_account=new JLabel("Account:");
	private JLabel l_phone=new JLabel("Phone:");
	private JLabel l_email=new JLabel("Email:");
	private JLabel l_sex=new JLabel("Sex:");
	private JTextArea t_id=new JTextArea(1,10);
	private JTextArea t_pass=new JTextArea(1,10);
	private JTextArea t_name=new JTextArea(1,10);
	private JTextArea t_account=new JTextArea(1,10);
	private JTextArea t_phone=new JTextArea(1,10);
	private JTextArea t_email=new JTextArea(1,10);
	private JTextArea t_sex=new JTextArea(1,10);
	private JButton b_ok=new JButton("OK");
	private JPanel p2=new JPanel(),p3=new JPanel(),p4=new JPanel();
	registerPanel(){
		p2.setLayout(new GridLayout(7,1,2,2));
		p3.setLayout(new GridLayout(7,1,2,2));
		p2.add(l_id);
		p2.add(l_pass);
		p2.add(l_account);
		p2.add(l_name);
		p2.add(l_phone);
		p2.add(l_email);
		p2.add(l_sex);
		p3.add(t_id);
		p3.add(t_pass);
		p3.add(t_account);
		p3.add(t_name);
		p3.add(t_phone);
		p3.add(t_email);
		p3.add(t_sex);
		p4.add(p2,BorderLayout.WEST);
		p4.add(p3, BorderLayout.EAST);
		p1.add(p4,BorderLayout.CENTER);
		p1.add(b_ok, BorderLayout.SOUTH);
		add(p1);
		b_ok.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String id=t_id.getText();
				String pass=t_pass.getText();
				String account=t_account.getText();
				String name=t_name.getText();
				String phone=t_phone.getText();
				String email=t_email.getText();
				String sex=t_sex.getText();
				ArrayList<Customer2014302580124> clist=new ArrayList<Customer2014302580124>();
				try {
					clist=db.readUserInfo();
					int i=0;
					for(;i<clist.size();i++) {
						if(id.equals(clist.get(i).getId())){
							card.show(loginpanel.getParent(), "2");//�����ظ����ص�¼����
							break;
						}//if
					}//for
					if(i==clist.size()){ 
						//���µ�ǰ�û��������û���Ϣд�����ݿ�
						customer=new Customer2014302580124(id,pass,account,name,phone,email,sex);
						showPanel showpanel=new showPanel(customer);
						cardpanel.add(showpanel,"4");
						db.writeUserInfo(customer);
						//��ת��չʾ����
						card.show(showpanel.getParent(),"4");
						}//if
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
	}
	
}//end class registerPanel
//չʾ���
class showPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DataBase2014302580124 db=new DataBase2014302580124();
	JPanel p1=new JPanel();
    JPanel g1=new JPanel(),g2=new JPanel(),g3=new JPanel(),g4=new JPanel(),
    		g5=new JPanel(),g6=new JPanel(),g7=new JPanel(),g8=new JPanel(),
    		g9=new JPanel(),g10=new JPanel(),g11=new JPanel(),g12=new JPanel();
    JTextArea t1=new JTextArea(4,12),t2=new JTextArea(4,12),t3=new JTextArea(4,12),t4=new JTextArea(4,12),
    		t5=new JTextArea(4,12),t6=new JTextArea(4,12),t7=new JTextArea(4,12),t8=new JTextArea(4,12),
    		t9=new JTextArea(4,12),t10=new JTextArea(4,12),t11=new JTextArea(4,12),t12=new JTextArea(4,12);
	JButton b1=new JButton("�鿴��Ʒ��Ϣ"),b2=new JButton("�鿴��Ʒ��Ϣ"),b3=new JButton("�鿴��Ʒ��Ϣ"),b4=new JButton("�鿴��Ʒ��Ϣ"),
			b5=new JButton("�鿴��Ʒ��Ϣ"),b6=new JButton("�鿴��Ʒ��Ϣ"),b7=new JButton("�鿴��Ʒ��Ϣ"),b8=new JButton("�鿴��Ʒ��Ϣ"),
		    b9=new JButton("�鿴��Ʒ��Ϣ"),b10=new JButton("�鿴��Ʒ��Ϣ"),b11=new JButton("�鿴��Ʒ��Ϣ"),b12=new JButton("�鿴��Ʒ��Ϣ");
 
	ArrayList<Pet2014302580124> plist=new ArrayList<Pet2014302580124>();
	showPanel(Customer2014302580124 curcustomer) {	
		try {
			plist=db.readPetInfo();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0;i<plist.size();i++) 
			glist.add(new Goods2014302580124(plist.get(i),i+10,i+100));
	p1.setLayout(new GridLayout(4,3,5,2));		
	t1.setText("id:"+glist.get(0).getPet().getId()+"\n"+"name:"+glist.get(0).getPet().getName()+"\n"+"number:"+glist.get(0).getNumber()+"\n"+"price:"+glist.get(0).getPrice());
	t2.setText("id:"+glist.get(1).getPet().getId()+"\n"+"name:"+glist.get(1).getPet().getName()+"\n"+"number:"+glist.get(1).getNumber()+"\n"+"price:"+glist.get(1).getPrice());
	t3.setText("id:"+glist.get(2).getPet().getId()+"\n"+"name:"+glist.get(2).getPet().getName()+"\n"+"number:"+glist.get(2).getNumber()+"\n"+"price:"+glist.get(2).getPrice());
	t4.setText("id:"+glist.get(3).getPet().getId()+"\n"+"name:"+glist.get(3).getPet().getName()+"\n"+"number:"+glist.get(3).getNumber()+"\n"+"price:"+glist.get(3).getPrice());
	t5.setText("id:"+glist.get(4).getPet().getId()+"\n"+"name:"+glist.get(4).getPet().getName()+"\n"+"number:"+glist.get(4).getNumber()+"\n"+"price:"+glist.get(4).getPrice());
	t6.setText("id:"+glist.get(5).getPet().getId()+"\n"+"name:"+glist.get(5).getPet().getName()+"\n"+"number:"+glist.get(5).getNumber()+"\n"+"price:"+glist.get(5).getPrice());
	t7.setText("id:"+glist.get(6).getPet().getId()+"\n"+"name:"+glist.get(6).getPet().getName()+"\n"+"number:"+glist.get(6).getNumber()+"\n"+"price:"+glist.get(6).getPrice());
	t8.setText("id:"+glist.get(7).getPet().getId()+"\n"+"name:"+glist.get(7).getPet().getName()+"\n"+"number:"+glist.get(7).getNumber()+"\n"+"price:"+glist.get(7).getPrice());
	t9.setText("id:"+glist.get(8).getPet().getId()+"\n"+"name:"+glist.get(8).getPet().getName()+"\n"+"number:"+glist.get(8).getNumber()+"\n"+"price:"+glist.get(8).getPrice());
	t10.setText("id:"+glist.get(9).getPet().getId()+"\n"+"name:"+glist.get(9).getPet().getName()+"\n"+"number:"+glist.get(9).getNumber()+"\n"+"price:"+glist.get(9).getPrice());
	t11.setText("id:"+glist.get(10).getPet().getId()+"\n"+"name:"+glist.get(10).getPet().getName()+"\n"+"number:"+glist.get(10).getNumber()+"\n"+"price:"+glist.get(10).getPrice());
	t12.setText("id:"+glist.get(11).getPet().getId()+"\n"+"name:"+glist.get(11).getPet().getName()+"\n"+"number:"+glist.get(11).getNumber()+"\n"+"price:"+glist.get(11).getPrice());
	g1.add(t1, BorderLayout.NORTH);g1.add(b1,BorderLayout.SOUTH);
	g2.add(t2, BorderLayout.NORTH);g2.add(b2,BorderLayout.SOUTH);
	g3.add(t3, BorderLayout.NORTH);g3.add(b3,BorderLayout.SOUTH);
	g4.add(t4, BorderLayout.NORTH);g4.add(b4,BorderLayout.SOUTH);
	g5.add(t5, BorderLayout.NORTH);g5.add(b5,BorderLayout.SOUTH);
	g6.add(t6, BorderLayout.NORTH);g6.add(b6,BorderLayout.SOUTH);
	g7.add(t7, BorderLayout.NORTH);g7.add(b7,BorderLayout.SOUTH);
	g8.add(t8, BorderLayout.NORTH);g8.add(b8,BorderLayout.SOUTH);
	g9.add(t9, BorderLayout.NORTH);g9.add(b9,BorderLayout.SOUTH);
	g10.add(t10, BorderLayout.NORTH);g10.add(b10,BorderLayout.SOUTH);
	g11.add(t11, BorderLayout.NORTH);g11.add(b11,BorderLayout.SOUTH);
	g12.add(t12, BorderLayout.NORTH);g12.add(b12,BorderLayout.SOUTH);
	p1.add(g1);p1.add(g2);p1.add(g3);p1.add(g4);p1.add(g5);p1.add(g6);p1.add(g7);p1.add(g8);p1.add(g9);p1.add(g10);p1.add(g11);p1.add(g12);
	add(p1);
	ButtonListener  listener=new ButtonListener(curcustomer);
	b1.addActionListener(listener);b2.addActionListener(listener);b3.addActionListener(listener);
	b4.addActionListener(listener);b5.addActionListener(listener);b6.addActionListener(listener);
	b7.addActionListener(listener);b8.addActionListener(listener);b9.addActionListener(listener);
	b10.addActionListener(listener);b11.addActionListener(listener);b12.addActionListener(listener);
	}
	class ButtonListener implements ActionListener {
		private Customer2014302580124 curcustomer;
		public ButtonListener(Customer2014302580124 customer){
			this.curcustomer=customer;
		}
	    @Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==b1){
		    curgoods=glist.get(0);
		    detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
		    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");
			}
			else if(e.getSource()==b2){
				curgoods=glist.get(1);
				detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
				card.show(detailpanel.getParent(), "5");
				}
			else if(e.getSource()==b3){curgoods=glist.get(2);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			 cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");
			}
			else if(e.getSource()==b4){
				curgoods=glist.get(3);
				detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
				cardpanel.add(detailpanel,"5");
				card.show(detailpanel.getParent(), "5");
				}
			else if(e.getSource()==b5){
				curgoods=glist.get(4);
				detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
				cardpanel.add(detailpanel,"5");
				card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b6){curgoods=glist.get(5);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b7){curgoods=glist.get(6);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b8){curgoods=glist.get(7);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b9){curgoods=glist.get(8);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b10){curgoods=glist.get(9);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b11){curgoods=glist.get(10);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
			else if(e.getSource()==b12){curgoods=glist.get(11);
			 detailPanel detailpanel=new detailPanel(curgoods,curcustomer);
			    cardpanel.add(detailpanel,"5");
			card.show(detailpanel.getParent(), "5");}
		}
	}//end class Listener
}//end class showPanel
class detailPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel p1=new JPanel(),p2=new JPanel();
	private JTextArea t1=new JTextArea(8,15);
	private JTextArea t2=new JTextArea(1,15);
	private JButton b1=new JButton("���빺�ﳵ");
	detailPanel(Goods2014302580124 goods,Customer2014302580124 customer){	
	t1.setBorder(new TitledBorder("��Ʒ��ϸ��Ϣ"));	
    t2.setBorder(new TitledBorder("�����빺������"));
	t1.setText("ID:"+goods.getPet().getId()+"\n"+"Name:"+goods.getPet().getName()+
				"\n"+"Eat:"+goods.getPet().getEat()+"\n"+"Drink:"+goods.getPet().getDrink()+
				"\n"+"Live:"+goods.getPet().getLive()+"\n"+"Hobby:"+goods.getPet().getHobby()+
				"\n"+"Price:"+goods.getPrice()+"\n"+"Number:"+goods.getNumber());		
		p2.add(t1,BorderLayout.NORTH);
		p2.add(t2, BorderLayout.CENTER);
		p2.add(b1,BorderLayout.SOUTH);
		p1.add(p2);
		add(p1);
		
		
		b1.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			    ShoppingTrolley2014302580124 trolley =new ShoppingTrolley2014302580124();
				String num=t2.getText();
			
				trolley.setGoods(goods);
				trolley.setNumber(Integer.parseInt(num));
				customer.settrolley(trolley);
				trolleyPanel trolleypanel=new trolleyPanel(customer);
				cardpanel.add(trolleypanel,"6");
				card.show(trolleypanel.getParent(), "6");
				//card.show(mainpanel.getParent(), "1");
			}
			
		});
	}
}//end class detailPanel
class trolleyPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel p1=new JPanel(),p2=new JPanel();
	JTextArea t1=new JTextArea(10,15),t2=new JTextArea(10,15);
	
	trolleyPanel(Customer2014302580124 customer){
		t1.setBorder(new TitledBorder("�û���Ϣ"));
		t1.setText("ID:"+customer.getId()+"\n"+"Name:"+customer.getName()+"\n"+
	"Account:"+customer.getAccount()+"\n"+"Phone:"+customer.getPhone()+"\n"+
				"Email:"+customer.getEmail()+"\n"+"Sex:"+customer.getSex());
		t2.setBorder(new TitledBorder("������Ϣ"));
		t2.setText("Name:"+customer.gettrolley().getGoods().getPet().getName()+"\n"+
				"Number:"+customer.gettrolley().getNumber()+"\n"+
				"TotalCost:"+customer.gettrolley().getNumber()*customer.gettrolley().getGoods().getPrice());
		p2.add(t1,BorderLayout.WEST);
		p2.add(t2, BorderLayout.EAST);
		p1.add(p2);
		add(p1);
	}
}//end class trolleyPanel
}//end class GUIMain2014302580124

