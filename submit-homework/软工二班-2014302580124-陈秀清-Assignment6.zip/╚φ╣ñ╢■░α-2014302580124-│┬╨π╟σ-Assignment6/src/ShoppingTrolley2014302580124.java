
public class ShoppingTrolley2014302580124 {
private Goods2014302580124 goods;
private int number;
public Goods2014302580124 getGoods() {
	return goods;
}
public void setGoods(Goods2014302580124 goods) {
	this.goods = goods;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}

}
