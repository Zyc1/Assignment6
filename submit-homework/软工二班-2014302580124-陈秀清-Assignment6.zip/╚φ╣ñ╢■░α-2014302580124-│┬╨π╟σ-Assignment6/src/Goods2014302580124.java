
public class Goods2014302580124 {
private Pet2014302580124 pet;
private float price;
private int number;
Goods2014302580124(){
	
}
Goods2014302580124(Pet2014302580124 pet,int number,float price){
	this.pet=pet;
	this.number=number;
	this.price=price;
}
public Pet2014302580124 getPet() {
	return pet;
}
public void setPet(Pet2014302580124 pet) {
	this.pet = pet;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}

}
