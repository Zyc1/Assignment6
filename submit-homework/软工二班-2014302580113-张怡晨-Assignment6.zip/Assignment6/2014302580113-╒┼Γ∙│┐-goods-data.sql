/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.27-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('1','dog','1300','95');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('2','cat','3000','98');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('3','turtle','30','100');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('4','parrot','25','92');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('5','hamster','20','100');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('6','squirrel','50','100');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('7','rabbit','18','90');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('8','snake','400','99');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('9','lizard','200','100');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('10','fish','8','98');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('11','myna','70','98');
insert into `2014302580113_goods` (`id`, `name`, `price`, `numberavailable`) values('12','canary','60','97');
