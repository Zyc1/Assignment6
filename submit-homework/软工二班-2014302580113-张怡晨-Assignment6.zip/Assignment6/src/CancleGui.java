import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;


public class CancleGui extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;


	/**
	 * Create the frame.
	 */
	public CancleGui(Customer customer) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblid = new JLabel("\u5546\u54C1ID");
		lblid.setBounds(40, 46, 81, 21);
		contentPane.add(lblid);
		
		textField = new JTextField();
		textField.setBounds(149, 43, 178, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		//���ȷ�Ϻ�ɾ�����ﳵ��ָ��������ָ����Ʒ�����ع��ﳵҳ��
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = Integer.parseInt(textField.getText());
				int number = Integer.parseInt(textField_1.getText());
				try {
					customer.getCart().deleteGoods(id, number,customer.getUid());
					setVisible(false);
					CartGui frame = new CartGui(customer);
					frame.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button.setBounds(106, 178, 95, 29);
		contentPane.add(button);
		
		//���ع��ﳵҳ��
		JButton btnNewButton = new JButton("\u53D6\u6D88");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				CartGui frame = new CartGui(customer);
				frame.setVisible(true);
			}
		});
		btnNewButton.setBounds(216, 178, 95, 29);
		contentPane.add(btnNewButton);
		
		JLabel label = new JLabel("\u5220\u9664\u6570\u91CF");
		label.setBounds(40, 109, 81, 21);
		contentPane.add(label);
		
		textField_1 = new JTextField();
		textField_1.setBounds(149, 106, 178, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
	}
}
