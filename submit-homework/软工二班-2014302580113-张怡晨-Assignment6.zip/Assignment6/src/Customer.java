import java.sql.SQLException;


public class Customer  {
	private String name;
	private String account;
	private String password;
	private int uid;
	private String phoneNumber;
	private Cart cart;//���ﳵ
	private Order order;//����
	
	public String getName(){
		return name;
	}
	
	public String getPhoneNumber(){
		return phoneNumber;	
	}
	
	public String getAccount(){
		return account;	
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public void setPhoneNumber(String phoneNumber){
		this.phoneNumber=phoneNumber;
	}
	
	public void setAccount(String account){
		this.account=account;
	}
	
	public void setCart(Cart cart){
		this.cart=cart;
	}
	
	public void setOrder(Order order){
		this.order=order;
	}
	
	public Cart getCart(){
		return cart;	
	}
	
	public Order getOrder(){
		return order;	
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Payment pay() throws SQLException{
		//���㶩���ܶ�
		OrderCalc calc = new OrderCalc();
		calc.calOrder(order);
		float totalPrice=calc.getTotalPrice();
		
		//�����µ�ƾ֤���������ݿ�
		Payment payment = new Payment(uid,totalPrice);
		DB my_db=new DB();
		my_db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
		
		//���֧���������Ʒ�Ŀ������ͬʱ����û��Ĺ����б�
		Object[] data=new Object[2];
		data[0]=uid;
		data[1]=totalPrice;
		my_db.insert("insert into 2014302580113_payment(uid,totalprice) values(?,?)", data);
		for(int i=0;i<order.getOrderList().size();i++){
			int purchaseNumber = order.getOrderList().get(i).getPurchaseNumber();
			int id =order.getOrderList().get(i).getId();
			int numberAvailable = (int) my_db.search(id, 4, "2014302580113_goods");
			int remainingNumber = numberAvailable-purchaseNumber;
			my_db.update("update 2014302580113_goods set numberavailable='"+remainingNumber+"' where id="+id);
			for(int j=0;j<cart.getGoodsList().size();j++){
				cart.getGoodsList().remove(j);
				}
		}
		return payment;
	}

}
