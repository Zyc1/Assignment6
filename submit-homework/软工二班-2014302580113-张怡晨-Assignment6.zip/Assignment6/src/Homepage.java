import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Homepage extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public Homepage(Customer customer) {
		setTitle("��Ʒ�б�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 445, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel(new GridLayout(4,3));
		contentPane.add(panel1,BorderLayout.CENTER);
	    
		//��ת�����ﳵҳ��
	    JButton btn = new JButton();
	    btn.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		CartGui frame = new CartGui(customer);
	    		frame.setVisible(true);
	    	}
	    });
	    btn.setText("\u6211\u7684\u8D2D\u7269\u8F66");
	    contentPane.add(btn,BorderLayout.SOUTH);
	    
	    /**
	     * ����������¼������ͼƬ����ת����Ʒ����ҳ��
	     */
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("dog.jpg"));
		panel1.add(lblNewLabel);
		lblNewLabel.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(1, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(1,3,"2014302580113_goods"));
					data.add(db.search(1,4,"2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("cat.jpg"));
		panel1.add(lblNewLabel_1);
		lblNewLabel_1.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(2, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(2,3,"2014302580113_goods"));
					data.add(db.search(2, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("turtle.jpg"));
		panel1.add(lblNewLabel_2);
		lblNewLabel_2.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(3, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(3,3,"2014302580113_goods"));
					data.add(db.search(3, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("parrot.jpg"));
		panel1.add(lblNewLabel_3);
		lblNewLabel_3.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(4, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(4,3,"2014302580113_goods"));
					data.add(db.search(4, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("hamster.jpg"));
		panel1.add(lblNewLabel_4);
		lblNewLabel_4.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(5, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(5,3,"2014302580113_goods"));
					data.add(db.search(5, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("squirrel.jpg"));
		panel1.add(lblNewLabel_5);
		lblNewLabel_5.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(6, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(6,3,"2014302580113_goods"));
					data.add(db.search(6, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("rabbit.jpg"));
		panel1.add(lblNewLabel_6);
		lblNewLabel_6.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(7, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(7,3,"2014302580113_goods"));
					data.add(db.search(7, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon("snake.jpg"));
		panel1.add(lblNewLabel_7);
		lblNewLabel_7.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(8, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(8,3,"2014302580113_goods"));
					data.add(db.search(8, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setIcon(new ImageIcon("lizard.jpg"));
		panel1.add(lblNewLabel_8);
		lblNewLabel_8.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(9, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(9,3,"2014302580113_goods"));
					data.add(db.search(9, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setIcon(new ImageIcon("fish.jpg"));
		panel1.add(lblNewLabel_9);
		lblNewLabel_9.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(10, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(10,3,"2014302580113_goods"));
					data.add(db.search(10, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_10 = new JLabel("");
		lblNewLabel_10.setIcon(new ImageIcon("myna.jpg"));
		panel1.add(lblNewLabel_10);
		lblNewLabel_10.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(11, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(11,3,"2014302580113_goods"));
					data.add(db.search(11, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
		
		JLabel lblNewLabel_11 = new JLabel("");
		lblNewLabel_11.setIcon(new ImageIcon("canary.jpg"));
		panel1.add(lblNewLabel_11);
		lblNewLabel_11.addMouseListener(new MouseAdapter(){  
			public void  mouseClicked(MouseEvent e) {  
				DB db = new DB();
				db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				List data = new ArrayList();
				for(int i=0;i<6;i++){
					try {
						data.add(db.search(12, i+1, "2014302580113_pet"));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					data.add(db.search(12,3,"2014302580113_goods"));
					data.add(db.search(12, 4, "2014302580113_goods"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Details frame = new Details(data,customer);
				frame.setVisible(true);
			} });
	}
}
