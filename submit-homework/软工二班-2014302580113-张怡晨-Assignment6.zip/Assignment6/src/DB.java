import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DB {
	private String connectionString;
	private String user;
	private String password;
	Connection mycon = null;
	
	//�������ݿ�
	public void getConnection(String connectionString,String user,String password)
	{
		this.connectionString = connectionString;
		this.user = user;
		this.password = password;
		
		try {
        	Class.forName("com.mysql.jdbc.Driver");
            mycon = DriverManager.getConnection(connectionString,user,password);
            } catch (Exception e) {
    				e.printStackTrace();
    		}
	}
	
		//�����ݿ��в�������
		public void insert(String sql,Object[] data) throws SQLException
		{
			PreparedStatement st = null;
			try{
				st = mycon.prepareStatement(sql);
				for(int i=0;i<data.length;i++){
			        st.setObject(i+1, data[i]);
				}
			     st.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	
	//����id��������
	public Object search(int id,int column,String table) throws SQLException
	{
		Statement st=null;
	    ResultSet rs=null;
	    Object result = null;
	    try{
		    st=mycon.createStatement();
		    String sql="select * from "+table;
	        rs=st.executeQuery(sql);
	
		    while(rs.next())
	        {
		    	if(rs.getString(1).equals(Integer.toString(id))){
		    		result = rs.getObject(column);
		    	}
	        }
	    }catch (Exception e) {
			e.printStackTrace();
		}
	    return result;
	}

		//����idɾ�����ݿ�����		
		public void delete(String tableName,int id)  
		{  
			String sql = "delete from '"+tableName+"' where id="+id; 
			Statement st = null; 
			try{  
				st=mycon.createStatement();
				st.executeUpdate(sql);
			}catch (SQLException e){  
				e.printStackTrace();  
			}   
		}  


		//�������ݿ�����
		public void update(String sql){
			PreparedStatement st = null;
		    try{
			    st=mycon.prepareStatement(sql);
			    st.executeUpdate();
		        }catch (SQLException e){  
					e.printStackTrace();  
				}   
		}
		
		//�û���¼��֤
		public int authenticateUser (String account,String password) throws SQLException
		  {
			Statement st=null;
		    ResultSet rs=null;
		    int i=0;
		    int id=0;
		    try{
			    st=mycon.createStatement();
			    String sql="select * from 2014302580113_customer";
		        rs=st.executeQuery(sql);
		
			    while(rs.next()){
			    	if(rs.getString("account").equals(account) && rs.getString("password").equals(password)){
			    		i=1;
			    		id =rs.getInt("uid");
			    	}
		        }
		    	}catch (Exception e) {
				e.printStackTrace();
		    	}
		    if(i==1)return id;
		    else return -1;
		  }
}
