import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;


public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;
	private JTextField txt3;
	private JTextField txt4;


	/**
	 * Create the frame.
	 */
	public Register(Customer customer) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 453, 513);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8D26\u53F7");
		label.setBounds(65, 73, 81, 21);
		contentPane.add(label);
		
		
		JLabel label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(65, 157, 81, 21);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u59D3\u540D");
		label_2.setBounds(65, 239, 81, 21);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u7535\u8BDD");
		label_3.setBounds(65, 329, 81, 21);
		contentPane.add(label_3);
		
		//ע��ʱ����һ���µ��û���ע����ɺ�ֱ����ת����ҳ��
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String account = txt1.getText();
				String password = txt2.getText();
				String name = txt3.getText();
				String phoneNumber = txt4.getText();
				DB my_db = new DB();
				my_db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				int uid = 0;
				Object[] data = {uid,name,account,password,phoneNumber};
				try {
					my_db.insert("insert into 2014302580113_customer(uid,name,account,password,phoneNumber) values(?,?,?,?,?)", data);
					uid = my_db.authenticateUser(account, password);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Cart cart = new Cart();
				Order order = new Order();
				customer.setUid(uid);
				customer.setName(name);
				customer.setAccount(account);
				customer.setPassword(password);
				customer.setPhoneNumber(phoneNumber);
				customer.setCart(cart);
				customer.setOrder(order);
				setVisible(false);
				Homepage frame = new Homepage(customer);
				frame.setVisible(true);
			}
		});
		button.setBounds(141, 411, 123, 29);
		contentPane.add(button);
		
		txt1 = new JTextField();
		txt1.setBounds(155, 70, 171, 27);
		contentPane.add(txt1);
		txt1.setColumns(10);
		
		txt2 = new JTextField();
		txt2.setBounds(155, 154, 171, 27);
		contentPane.add(txt2);
		txt2.setColumns(10);
		
		txt3 = new JTextField();
		txt3.setBounds(155, 236, 171, 27);
		contentPane.add(txt3);
		txt3.setColumns(10);
		
		txt4 = new JTextField();
		txt4.setBounds(155, 326, 171, 27);
		contentPane.add(txt4);
		txt4.setColumns(10);
	}

}
