import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Customer customer = new Customer();
					Login frame = new Login(customer);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login(Customer customer) {
		setBackground(new Color(240, 240, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 511);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u7528\u6237\u540D");
		label.setBounds(70, 106, 75, 21);
		contentPane.add(label);
		
		//�����˺�
		txt1 = new JTextField();
		txt1.setBounds(160, 103, 176, 27);
		contentPane.add(txt1);
		txt1.setColumns(10);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(70, 206, 75, 21);
		contentPane.add(label_1);
		
		//��������
		txt2 = new JTextField();
		txt2.setBounds(160, 203, 176, 27);
		contentPane.add(txt2);
		txt2.setColumns(10);
		
		//��¼
		JButton login_btn = new JButton("\u767B\u5F55");
		login_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String account=txt1.getText();
				String password=txt2.getText();
				Connection mycon = null;
				DB my_db=new DB();
				my_db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
				try {
					if(my_db.authenticateUser(account, password)>=0){
						Cart cart = new Cart();
						Order order = new Order();
						int uid = my_db.authenticateUser(account, password);
						customer.setUid(uid);
						customer.setName((String)my_db.search(uid, 2, "2014302580113_customer"));
						customer.setPhoneNumber((String)my_db.search(uid, 5, "2014302580113_customer"));
						customer.setAccount(account);
						customer.setPassword(password);
						customer.setCart(cart);
						customer.setOrder(order);
						setVisible(false);
						Homepage frame = new Homepage(customer);
						frame.setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		login_btn.setBounds(103, 339, 81, 29);
		contentPane.add(login_btn);
		
		//��ת��ע��ҳ��
		JButton regist_btn = new JButton("\u6CE8\u518C");
		regist_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register frame = new Register(customer);
				frame.setVisible(true);
			}
		});
		regist_btn.setBounds(264, 339, 81, 29);
		contentPane.add(regist_btn);
	}
}
