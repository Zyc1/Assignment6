

public class Payment {
	
	private float totalPrice;
	private int uid;

	public Payment(int pid,float totalPrice){
		this.totalPrice=totalPrice;
		this.uid=pid;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getNumber() {
		return uid;
	}

	public void setNumber(int pid) {
		this.uid = uid;
	}
}
