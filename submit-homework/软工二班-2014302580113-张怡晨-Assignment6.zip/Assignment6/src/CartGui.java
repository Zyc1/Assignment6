import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class CartGui extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public CartGui(Customer customer)  {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 444, 524);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		//��ʾ�û����ﳵ�е���Ʒ
		JTextArea area = new JTextArea();
		area.setBackground(SystemColor.controlHighlight);
		area.setEditable(false);
		contentPane.add(area,BorderLayout.CENTER);
		area.append("�����ﳵ�е���Ʒ�У�\n");
		int number=customer.getCart().getGoodsList().size();
		DB db = new DB();
		db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
		for(int i=0;i<number;i++){
			String name;
			try {
				area.append(String.valueOf(customer.getCart().getGoodsList().get(i).getID())+"  ");
				name = (String) db.search(customer.getCart().getGoodsList().get(i).getID(), 2, "2014302580113_goods");
				area.append(name+"  ");
				float price = (float) db.search(customer.getCart().getGoodsList().get(i).getID(), 3, "2014302580113_goods");
				area.append(price+"*"+String.valueOf(customer.getCart().getGoodsList().get(i).getPurchaseNumber())+"\n");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}			
		}
		
		area.setFont(new Font("Serif",Font.PLAIN,20));
		
		JPanel panel = new JPanel(new GridLayout(1,3));
		
		//ȷ��֧��
	    JButton btn1 = new JButton();
	    btn1.setText("\u786E\u8BA4\u652F\u4ED8");
	    btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float total;
				try {
					customer.getOrder().addOrderItemFromCart(customer.getCart(),customer.getUid());
					total = customer.pay().getTotalPrice();
					JOptionPane.showMessageDialog(contentPane, "����"+total+"Ԫ��֧���ɹ�","֧����Ϣ",JOptionPane.PLAIN_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
			}
		});
	    panel.add(btn1);
	    
	    //��ת��ɾ�����ﳵ����Ʒ��ҳ��
	    JButton btn2 = new JButton();
	    btn2.setText("\u5220\u9664\u5546\u54C1");
	    panel.add(btn2);
	    btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				CancleGui frame = new CancleGui(customer);
				frame.setVisible(true);
			}
		});
	    
	    //������أ���ת����ҳ��
	    JButton btn3 = new JButton();
	    btn3.setText("\u8FD4\u56DE");
	    panel.add(btn3);
	    btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Homepage frame = new Homepage(customer);
				frame.setVisible(true);
			}
		});
	    
	    contentPane.add(panel,BorderLayout.SOUTH);
		}

}
