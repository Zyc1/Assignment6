import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Order {
	private List<OrderItem> orderList = new ArrayList();
	
	//�����ﳵ�е���Ʒ���붩��
	public void addOrderItemFromCart(Cart cart,int uid) throws SQLException{
		DB my_db = new DB();
		my_db.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
		int length=cart.getGoodsList().size();
		for(int i=0;i<length;i++){
			int id=cart.getGoodsList().get(i).getID();
			int purchaseNumber=cart.getGoodsList().get(i).getPurchaseNumber();
			String name=String.valueOf(my_db.search(id, 2, "2014302580113_goods")) ;
			float price=(float) my_db.search(id, 3, "2014302580113_goods");
			OrderItem item=new OrderItem(id,name,price,purchaseNumber);
			orderList.add(item);
		}
	}
	
	//��ö���
	public List<OrderItem> getOrderList(){
		return orderList;	
	}
}
