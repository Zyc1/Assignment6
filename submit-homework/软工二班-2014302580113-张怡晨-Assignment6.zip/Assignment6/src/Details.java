import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;


public class Details extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public Details(List data,Customer customer) {
		setTitle("��Ʒ����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 444, 521);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout());
		
		//��ʾ��Ʒ����ϸ��Ϣ
		JTextArea area = new JTextArea();
		area.setBackground(SystemColor.controlHighlight);
		area.setEditable(false);
		contentPane.add(area,BorderLayout.CENTER);
		area.append("id:"+data.get(0)+"\n name:"+data.get(1)+"\n eat:"+data.get(2)+"\n drink:"+data.get(3)
				+"\n live:"+data.get(4)+"\n hobby:"+data.get(5)+"\n price:"+data.get(6)+"\n numberAvailable:"+data.get(7));
		area.setFont(new Font("Serif",Font.PLAIN,20));
		
		//�������ť����Ʒ���빺�ﳵ�������б�������Ӧ��
		JPanel panel = new JPanel(new GridLayout(1,2));
	    JButton btn1 = new JButton();
	    btn1.setText("\u8D2D\u4E70");
	    btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String purchaseNumber = JOptionPane.showInputDialog(contentPane, "�����빺������:");  
				try {
					if(purchaseNumber!=null)
						customer.getCart().addGoods(Integer.parseInt(String.valueOf(data.get(0))), Integer.parseInt(purchaseNumber),customer.getUid());
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	    panel.add(btn1);
	    
	    //������ذ�ť��ת����ҳ��
	    JButton btn2 = new JButton();
	    btn2.setText("\u8FD4\u56DE");
	    panel.add(btn2);
	    btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);				
			}
		});
	    
	    contentPane.add(panel,BorderLayout.SOUTH);
	}

}
