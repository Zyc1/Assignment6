/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.27-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580113_customer` (
	`uid` int (11),
	`name` varchar (765),
	`account` varchar (765),
	`password` varchar (765),
	`phoneNumber` varchar (765)
); 
