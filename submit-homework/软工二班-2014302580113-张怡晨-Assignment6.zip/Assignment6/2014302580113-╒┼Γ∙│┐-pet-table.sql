/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.27-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580113_pet` (
	`id` int (11),
	`name` varchar (765),
	`eat` varchar (765),
	`drink` varchar (765),
	`live` varchar (765),
	`hobby` varchar (765)
); 
