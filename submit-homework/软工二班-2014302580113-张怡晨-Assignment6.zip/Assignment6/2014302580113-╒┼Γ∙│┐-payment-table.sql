/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.27-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580113_payment` (
	`uid` int (11),
	`totalprice` float 
); 
