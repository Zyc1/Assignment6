/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.27-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('1','dog','bone','water','ground','play');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('2','cat','fish','milk','roof','hug');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('3','turtle','fish,shrimp','sea water','sea water','bask');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('4','parrot','nuts,seeds','water','tree','fly');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('5','hamster','Sunflower seed','water','corner','eat');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('6','squirrel','pine cone','water','tree hole,underground','play');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('7','rabbit','carrot','water','grassland,underground','eat');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('8','snake','mouse','water','hole','bask');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('9','lizard','bug','water','tree','bask');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('10','fish','aquatic plant','water','water','swim');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('11','myna','earthworm','water','tree','fly');
insert into `2014302580113_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`) values('12','canary','millet','water','tree','sing');
