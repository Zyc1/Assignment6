/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.6.27-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `2014302580113_customer` (`uid`, `name`, `account`, `password`, `phoneNumber`) values('1','1','1','1','1');
insert into `2014302580113_customer` (`uid`, `name`, `account`, `password`, `phoneNumber`) values('2','张三','12345','54321','123456789');
insert into `2014302580113_customer` (`uid`, `name`, `account`, `password`, `phoneNumber`) values('3','张三','123','123','123456789');
