import java.util.ArrayList;

public class ShopingCart {
	 ArrayList<PetBuy> petbuyed;

	 public ShopingCart(){
		 petbuyed=new ArrayList<PetBuy>();
	 }
	
}
