
public class Pet {

	int id;
	String name,eat,drink,live,hobby;
	int price;
	//int petnumber;
    
	public Pet(){}
	public Pet(int id,String name,String eat,String drink,String live,String hoppy,int price){
		this.id=id;
		this.name=name;
		this.eat=eat;
		this.drink=drink;
		this.live=live;
		this.hobby=hobby;
		this.price=price;
	}
	
}
