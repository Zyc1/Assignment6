import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;
public class MainGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Begin();
	}

}

//��¼����
class Begin extends JFrame{
	private User user;	
	public Begin(){
		JFrame p1=new JFrame();
		p1.setTitle("��¼");
		p1.setBounds(400,200, 550, 350);
		p1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p1.setLayout(null);
		p1.setVisible(true);
		JLabel l1=new JLabel("Welcome to my shop!");
		l1.setSize(150,20);
		l1.setLocation(100,20);
		JLabel l2=new JLabel("Please enter your username:");
		l2.setSize(200,20);
		l2.setLocation(100,60);
		JTextField t1=new JTextField();
		t1.setSize(100,20);
		t1.setLocation(270,60);
		p1.add(t1);
		JLabel l3=new JLabel("Please enter your password:");
		l3.setSize(200,20);
		l3.setLocation(100,100);
		JPasswordField jp=new JPasswordField(20);
		jp.setSize(100,20);
		jp.setLocation(270,100);
		p1.add(jp);
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		Button button1=new Button("��¼");
		button1.setSize(100,30);
		button1.setLocation(200,150);
		p1.add(button1);
		p1.repaint();
		button1.addActionListener(new ActionListener(){
			public User userAuthenticated() throws ClassNotFoundException, SQLException{
				String username=t1.getText();
				String password=new String(jp.getPassword());
				user=DataReader.Login(username,password);
				return user;
				
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					if(userAuthenticated()!=null){
						p1.dispose();
						//new Infor();
						new Infor(userAuthenticated());
					}
					else{
						JLabel jl=new JLabel("username or password is incorrect!");
						JOptionPane.showMessageDialog(p1,
								"username or password is incorrect!");
						t1.setText("");
						jp.setText("");
					}
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		
		JLabel l4=new JLabel("û���˺ţ�����ע�ᣡ");
		l4.setSize(150, 20);
		l4.setLocation(100, 230);
		p1.add(l4);
		Button button2=new Button("ע��");
		button2.setSize(100,30);
		button2.setLocation(270, 225);
		p1.add(button2);
		p1.repaint();
		button2.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				p1.dispose();
				new Regi();
			}
			
		});
		
	}
}

//ע�����
class Regi extends JFrame{
	public Regi(){
		JFrame p1=new JFrame();
		p1.setTitle("ע��");
		p1.setBounds(400,200, 550, 350);
		p1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p1.setLayout(null);
		p1.setVisible(true);
		JLabel l1=new JLabel("Welcome to my shop!");
		l1.setSize(150,20);
		l1.setLocation(100,20);
		JLabel l2=new JLabel("Please enter your username:");
		l2.setSize(200,20);
		l2.setLocation(100,60);
		JTextField t1=new JTextField();
		t1.setSize(100,20);
		t1.setLocation(270,60);
		p1.add(t1);
		JLabel l3=new JLabel("Please enter your password:");
		l3.setSize(200,20);
		l3.setLocation(100,100);
		JPasswordField jp=new JPasswordField(20);
		jp.setSize(100,20);
		jp.setLocation(270,100);
		p1.add(jp);
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		Button button1=new Button("ע��");
		button1.setSize(100,30);
		button1.setLocation(200,150);
		p1.add(button1);
		p1.repaint();
		button1.addActionListener(new ActionListener(){
			public boolean userRegister() throws ClassNotFoundException, SQLException {
				String username=t1.getText();
				String password=new String(jp.getPassword());
				if(username.equals("")||password.equals("")){
					return false;
				 }
				boolean b=DataReader.Register(username,password);
				return b;
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					if(userRegister()==true){
						JOptionPane.showMessageDialog(p1,
								"ע��ɹ���");
						p1.dispose();
						new Begin();
					}
					else{
						//JLabel jl=new JLabel("�û������ڻ򲻺Ϸ�");
						JOptionPane.showMessageDialog(p1,
								"�û������ڻ򲻺Ϸ�");
						t1.setText("");
						jp.setText("");
					}
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
	}
}

//������Ϣ����
class Infor extends JFrame{
	 DataReader dataReader;
	 ArrayList<Pet> pets;
	 ArrayList<PetBuy> petbuys;
	PetBuy petbuy;
	 Pet pet;
	 Button[] petButton;
	public Infor(User user) throws ClassNotFoundException, SQLException{
		JFrame p1=new JFrame();
		p1.setTitle("MyShop-----username:"+user.username);
		//p1.setTitle(user.username);
		petbuys=user.shopingcart.petbuyed;
		//Pet pet;
		
		p1.setBounds(400,200, 550, 350);
		p1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p1.setLayout(null);
		p1.setVisible(true);
		dataReader=new DataReader();
		pets=dataReader.petInfo();
		petbuys=new ArrayList<PetBuy>();
		petButton=new Button[12];
		user=new User();
		
		for(int i=0;i<12;i++){
		   // int i=0;
			//pet=pets.get(i);
			int j=i;
			String petName=pets.get(i).name;
			String petEat=pets.get(i).eat;
			String petDrink=pets.get(i).drink;
			String petLive=pets.get(i).live;
			String petHobby=pets.get(i).hobby;
			int petPrice=pets.get(i).price;
			petButton[i]=new Button(petName);
			petButton[i].setSize(100, 30);
			petButton[i].setLocation(75+(i%3)*150, 30+(i%4)*60);
			p1.add(petButton[i]);
			petButton[i].addActionListener(new ActionListener(){
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					p1.dispose();
					JFrame p2=new JFrame();
					p2.setTitle(petName);
					p2.setBounds(400,200,550,350);
					p2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					p2.setLayout(null);
					p2.setVisible(true);
					JLabel l1=new JLabel("The information of "+petName);
					l1.setSize(350,30);
					l1.setLocation(100,40);
					p2.add(l1);
					JLabel l2=new JLabel("Name: "+petName);
					l2.setSize(350,30);
					l2.setLocation(100,60);
					p2.add(l2);
					JLabel l3=new JLabel("Eat:"+petEat);
					l3.setSize(350,30);
					l3.setLocation(100,80);
					p2.add(l3);
					JLabel l4=new JLabel("Drink:"+petDrink);
					l4.setSize(350,30);
					l4.setLocation(100,100);
					p2.add(l4);
					JLabel l5=new JLabel("Live:"+petLive);
					l5.setSize(350,30);
					l5.setLocation(100,120);
					p2.add(l5);
					JLabel l6=new JLabel("Hobby:"+petHobby);
					l6.setSize(350,30);
					l6.setLocation(100,140);
					p2.add(l6);
					JLabel l7=new JLabel("Price($):"+petPrice);
					l7.setSize(350,30);
					l7.setLocation(100,160);
					p2.add(l7);
					JLabel l8=new JLabel("�����빺��������");
					l8.setSize(130,30);
					l8.setLocation(80,200);
					p2.add(l8);
					JTextField t1=new JTextField();
					t1.setSize(50,20);
					t1.setLocation(200,205);
					p2.add(t1);
					Button button1=new Button("���빺�ﳵ");
					button1.setSize(100,30);
					button1.setLocation(300,200);
					p2.add(button1);
					Button button2=new Button("����");
					button2.setSize(100,30);
					button2.setLocation(300,250);
					p2.add(button2);
					p2.repaint();
					//������Ӧ
					button2.addActionListener(new ActionListener(){

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							p2.setVisible(false);
							p1.setVisible(true);
						}
						
					});
					
					//���빺�ﳵ��Ӧ
					button1.addActionListener(new ActionListener(){
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							int num=Integer.parseInt(t1.getText());
							if(num>0){
								//this.petbuy=petbuy;
								 PetBuy petbuy=new PetBuy();
								 Pet pet=pets.get(j);
								 petbuy.pet=pet;
								//petbuy.pet=pets.get(i);
								petbuy.number=petbuy.number+num;
								petbuys.add(petbuy);
								JOptionPane.showMessageDialog(p2,
										"���빺�ﳵ�ɹ���");
							}
							else{
								JOptionPane.showMessageDialog(p2,
										"��������");
							}
						}
						
					});
				}
				
			});
		}
		Button button=new Button("�ҵĹ��ﳵ");
		button.setSize(100,30);
		button.setLocation(225,260);
		p1.add(button);
		p1.repaint();
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				p1.setVisible(false);
				new ShopingCarts(petbuys,p1);
			}
		
		});
	}
}

//���ﳵ����
class ShopingCarts extends JFrame{
	
	ArrayList<PetBuy> petbuys;
	ShopingCart shopingcart;
	JFrame p;
	public ShopingCarts(ArrayList<PetBuy> petbuys,JFrame pp){
		p=new JFrame();
		p=pp;
		shopingcart=new ShopingCart();
		shopingcart.petbuyed=petbuys;
		JFrame p1=new JFrame();
		p1.setTitle("ShopingCart");
		//p1.setTitle(user.username);
		p1.setBounds(400,200,550,350);
		p1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p1.setLayout(null);
		p1.setVisible(true);
		JLabel l1=new JLabel("�ҵĹ��ﳵ��");
		l1.setSize(100,20);
		l1.setLocation(50,10);
		p1.add(l1);
		for(int i=0;i<shopingcart.petbuyed.size();i++)
		{
			JLabel l=new JLabel("���"+shopingcart.petbuyed.get(i).pet.name+"  ������"+shopingcart.petbuyed.get(i).number);
			//JLabel l=new JLabel("Pet:"+shopingcart.petbuyed.get(i).number);
			l.setSize(160,20);
			l.setLocation(20+240*(i%2),40+30*(i/2));
			p1.add(l);
			Button button2=new Button("ɾ��");
			button2.setSize(40,20);
			button2.setLocation(200+240*(i%2),40+30*(i/2));
			p1.add(button2);
			p1.repaint();
			button2.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					l.setVisible(false);
					p1.remove(button2);
				}
				
			});
			
		}
		Button button1=new Button("����");
		button1.setSize(80,30);
		button1.setLocation(400,250);
		p1.add(button1);
		p1.repaint();
		button1.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				p1.setVisible(false);
				p.setVisible(true);
				//Infor.setVisible(true);
			}
			
		});
		Button button3=new Button("����");
		button3.setSize(80,30);
		button3.setLocation(300, 250);
		p1.add(button3);
		p1.repaint();
		button3.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(p1,"����ɹ���");
			}
			
		});
	}
}


