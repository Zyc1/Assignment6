
public class PetBuy
{
		Pet pet;
		int number,price;
		
}