
public class User {

	String username,password;
	ShopingCart shopingcart;
	public User(){
		shopingcart=new ShopingCart();
	}
	
}
