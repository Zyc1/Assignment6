import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class DataReader {
	//public void readMysql() {
	 static String url= "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456 ";
	// static String url = "jdbc:mysql://localhost:3306/javademo?user=root&password=ZhangJie1441160&useUnicode=true&characterEncoding=UTF8";
		String pSql="SELECT * FROM 2014302580125_pet;";
		static String uSql="SELECT * FROM 2014302580125_user;";
		static Connection conn = null;
		public static Connection getConnection() throws ClassNotFoundException, SQLException{
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			return conn;
	}
//	}
	
	//�û�ע��
	 public static boolean Register(String username,String password) throws ClassNotFoundException, SQLException{
		 conn=getConnection();
		 PreparedStatement  pstmt=conn.prepareStatement(uSql);
		 ResultSet res=pstmt.executeQuery();
		 while(res.next())
		 {
			 if(username.equals(res.getString(1))){
				 return false;
			 }
		 }
		 String rSql="insert into 2014302580125_user(username,password) values('"+username+"','"+password+"');";
		 pstmt=conn.prepareStatement(rSql);
		 pstmt.executeUpdate(rSql);
    	 return true;
     }

	 //�û���¼
	 public static User Login(String username,String password) throws ClassNotFoundException, SQLException{
		 conn=getConnection();
		 int state=0;
		 User user=new User();
		 PreparedStatement  pstmt=conn.prepareStatement(uSql);
		 ResultSet res=pstmt.executeQuery();
		 while(res.next()){
			 if(username.equals(res.getString(1))&&password.equals(res.getString(2)))
			 {
				 user.username=res.getString(1);
				 state=1;
			 }
		 }
		 if(state==1)
			 return user;
		 else{
			return null;
		 }
		 //return null;
	 }
	
	 //����
	 public ArrayList<Pet> petInfo() throws ClassNotFoundException, SQLException
	 {
		 conn=getConnection();
		 ArrayList<Pet> pets=new ArrayList<Pet>();
		 PreparedStatement  pstmt=conn.prepareStatement(pSql);
		 ResultSet res=pstmt.executeQuery();
		 while(res.next())
		 {
			 Pet pet=new Pet();
			 pet.id=res.getInt(1);
			 pet.name=res.getString(2);
			 pet.eat=res.getString(3);
			 pet.drink=res.getString(4);
			 pet.live=res.getString(5);
			 pet.hobby=res.getString(6);
			 pet.price=Integer.valueOf(res.getString(7));
			 pets.add(pet);
		 }
		return pets;
	 }
	
}
