DROP TABLE IF EXISTS `2014302580125_pet`;
CREATE TABLE `2014302580125_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
  `price` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;



INSERT INTO `2014302580125_pet` VALUES (1,'dog','bone','water','ground','play','1000'),(2,'cat','fish','milk','roof','hug','900'),(3,'turtle','fish,shrimp','sea water','sea water','bask','5000'),(4,'parrot','nuts,seeds','water','tree','fly','5000'),(5,'hamster','Sunflower seed','water','corner','eat','2500'),(6,'squirrel','pine cone','water','tree hole,underground','play','1500'),(7,'rabbit','carrot','water','grassland,underground','eat','300'),(8,'snake','mouse','water','hole','bask','500'),(9,'lizard','bug','water','tree','bask','1200'),(10,'fish','aquatic plant','water','water','swim','600'),(11,'myna','earthworm','water','tree','fly','320'),(12,'canary','millet','water','tree','sing','500');
