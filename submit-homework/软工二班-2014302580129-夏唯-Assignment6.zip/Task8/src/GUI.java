import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class GUI extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTextArea account1;
	JTextArea password1;
	JFrame frame = new JFrame();
	public void creatStartGUI(){
		
		 frame.setTitle("Welcome to PINK petshop");
         frame.setBounds(100,100,400,500);
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
         JPanel p1=new JPanel();
		//�����P1ʹ�����겼��
		//�����˻�������������
		p1.setLayout(null);
	    JLabel account_name=new JLabel("�˺�:");
		account_name.setBounds(110,100,30,20);
		p1.add(account_name);
		account1=new JTextArea();
		account1.setLineWrap(true);
		JScrollPane account2 = new JScrollPane(account1);
		account2.setBounds(160, 100, 130, 20);
		p1.add(account2);
		
		JLabel password_name=new JLabel("����:");
		password_name.setBounds(110,160, 30, 20);
		 p1.add(password_name);
		 password1=new JTextArea();
		password1.setLineWrap(true);
		JScrollPane password2 = new JScrollPane(password1);
		password2.setBounds(160, 160, 130, 20);
	    p1.add(password2);
	    //���ӵ�¼��ע�ᰴť
	    JButton login=new JButton("��¼");
	   login.setBounds(110, 250, 60, 20);
	   login.addActionListener(new Respondl());
	   p1.add(login);
	   JButton register=new JButton("ע��");
	   register.setBounds(225, 250, 60, 20);
	   register.addActionListener(new Respondr());
	   p1.add(register);
      p1.setBackground(Color.pink);
	  frame.setContentPane(p1);
	  frame.setVisible(true);
	}
	//�ڲ��ദ����¼��ť������
	
class Respondl implements ActionListener{
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int isCorrect=0;
		Match m=new Match();
		try {
			isCorrect=m.matchUser(account1.getText(), password1.getText());
			if(isCorrect==0)
				 JOptionPane.showMessageDialog(null, "���˻�δ��ע��");
			else if(isCorrect==1)
				 JOptionPane.showMessageDialog(null, "�������");
			else
			{
				ShowPetPanel r=new ShowPetPanel();
				r.creatPetNameFrame();
				frame.dispose();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
}
//�ڲ��ദ��ע�ᰴť������
class Respondr implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		RegisterPanel r=new RegisterPanel();
		r.creatRegisterFrame();
		frame.dispose();
		
		
	}
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	GUI g=new GUI();
	g.creatStartGUI();
        
         
	}
	

}
