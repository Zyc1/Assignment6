import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class Match {

	private static  String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	
	
	private   Connection conn=null;

	// TODO Auto-generated method stub
	//���ӵ����ݿ�
	public  Connection getConnection(String url){
		
		try{
			  Class.forName("com.mysql.jdbc.Driver");
			 
		} catch (ClassNotFoundException e) {
			   // TODO Auto-generated catch block
			   e.printStackTrace();
			   System.out.print("\n���ݿ�����������");
		}
		 
		 try {
		       conn = (Connection) DriverManager.getConnection(url);
		       System.out.print("\n�ɹ����ӵ����ݿ�");
				  
			  } catch (SQLException e) {
			// TODO Auto-generated catch block
			   e.printStackTrace();
			   System.out.print("\nSQL����");
			  
			  }finally{
				  
			  }
		return conn;
		 }
	public int matchUser(String account,String password) throws SQLException{
		int judge=0;
		getConnection(url);  //���ӵ����ݿ�
		try{
			
			Statement stmt = (Statement) conn.createStatement();
			 ResultSet rs = stmt.executeQuery("SELECT  * FROM 2014302580129_user");
			 while (rs.next()){
	             if(account.equals(rs.getString(1)) ){
	            judge=1;
	          if(password.equals(rs.getString(2)))
	            	judge=2;
	          
			 } 
			 }
			
		}catch (SQLException e){
	              e.printStackTrace();
	          }finally{
	              conn.close();
	          }
		return judge;
	}
	
	
	public java.util.List<HashMap<String, String>>  matchPet() throws SQLException{
		
		getConnection(url);  //���ӵ����ݿ�
		//������ݿ��е����ݴ���data��
		java.util.List<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>();
		try{
		Statement stmt = (Statement) conn.createStatement();
		 ResultSet rs = stmt.executeQuery("SELECT  * FROM 2014302580129_pet");
		 while (rs.next()){
             HashMap<String,String> map = new HashMap<String,String>();
             map.put("id",rs.getString(1));
             map.put("name", rs.getString(2));
             map.put("eat", rs.getString(3));
             map.put("drink", rs.getString(4));
             map.put("live", rs.getString(5));
             map.put("hobby", rs.getString(6));
             map.put("price", rs.getString(7));
             data.add(map);
			
          }
		 } catch (SQLException e){
              e.printStackTrace();
          }finally{
              conn.close();
          }

		return data;
	}
	
	public int matchAccount(String account) throws SQLException{
		int isBe=0;
		getConnection(url);  //���ӵ����ݿ�
		try{
			
			Statement stmt = (Statement) conn.createStatement();
			 ResultSet rs = stmt.executeQuery("SELECT  * FROM 2014302580129_user");
			 while (rs.next()){
	             if(account.equals(rs.getString(1)) ){
	            isBe=1;
	         
	          
			 } 
			 }
			
		}catch (SQLException e){
	              e.printStackTrace();
	          }finally{
	              conn.close();
	          }
		return isBe;
	}
	
	
public void addUser(String addAccount,String addPassword) throws SQLException{
		getConnection(url);
		Statement stmt = (Statement) conn.createStatement();
		String addUser="insert into 2014302580129_user(account,password) values('"+addAccount+"','"+addPassword+"')";
	    stmt.executeUpdate(addUser);
	    conn.close();
	}
	
	
	
}












