import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MyTrolleyPanel {
	JFrame frame = new JFrame();
	JPanel p=new JPanel();
	static JPanel p1=new JPanel(new GridLayout(12,1));
	
	
public void showMyTrolley(){
	 frame.setTitle("My Trolley");
     frame.setBounds(100,100,400,500);
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
     JButton back=new JButton("����");
     back.addActionListener(new Respondb1());
     p.add(p1);
	  p.add(back);
	  p.setBackground(Color.pink);
	  frame.setContentPane(p);
     frame.setVisible(true);
}

public void addPet(String petName,String price,String amount) {
	// TODO Auto-generated method stub
	 JPanel p2=new JPanel(new GridLayout(1,3,10,10));
	int price1=Integer.parseInt(price);
	int amount1=Integer.parseInt(amount);
	 JLabel addPet=new JLabel(petName+"  ����Ϊ��"+amount);
	 p2.add(addPet);
	  JButton delete=new JButton("delete");
	   delete.addActionListener(new ActionListener(){
		   @Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
		   p1.remove(p2);
			MyTrolleyPanel m=new MyTrolleyPanel();
			m.showMyTrolley();
			frame.dispose();
		   }
	   });
	   
		  p2.add(delete);
		  JButton buy=new JButton("buy");
		    buy.addActionListener(new ActionListener(){
		    	@Override
		    	public void actionPerformed(ActionEvent e) {
		    		// TODO Auto-generated method stub
		    		 JOptionPane.showMessageDialog(null, "�㽫֧��:"+price1*amount1+"\nȷ��֧����");
		    	}
		    
		    });
			  p2.add(buy);
	 p1.add(p2);
	
	
	
	
}
class Respondb1 implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	ShowPetPanel s=new ShowPetPanel();
	try {
		s.creatPetNameFrame();
		frame.dispose();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
	
}

}



