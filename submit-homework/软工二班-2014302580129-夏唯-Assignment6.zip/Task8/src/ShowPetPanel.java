import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

public class ShowPetPanel {
	JFrame frame = new JFrame();
	JFrame frame1 = new JFrame();

	MyTrolleyPanel m1=new MyTrolleyPanel();

	private  java.util.List<HashMap<String,String>> information;
public void creatPetNameFrame() throws SQLException{
	 frame.setTitle("All Pets");
     frame.setBounds(100,100,400,500);
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     JPanel showPetPanel=new JPanel();
     showPetPanel.setLayout(new GridLayout(3,4));
     JButton[] b=new JButton[12];
     Match m=new Match();
     information=m.matchPet();
		for(int i=0;i<12;i++)
		{    
			int a=i;
			String s=information.get(i).get("id")+"-"+information.get(i).get("name");
			String all="Id:"+information.get(i).get("id")+"\nName:"+information.get(i).get("name")
					+"\nEat:"+information.get(i).get("eat")+"\nDrink:"+information.get(i).get("drink")
					+"\nLive:"+information.get(i).get("drink")+"\nHobby:"+information.get(i).get("hobby")
			        +"\nPrice:"+information.get(i).get("price");			
			b[i]=new JButton(s);
			b[i].setBackground(Color.pink);
			b[i].addActionListener(new ActionListener() {//�����������������¼�
				public void actionPerformed(ActionEvent e){
					
					 frame1.setTitle("Pets'information");
				     frame1.setBounds(100,100,400,500);
				     frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				    
				     JLabel title=new JLabel("The informations of this kind of pet:");
	                 title.setFont(new Font("Serif",Font.BOLD,16));
				     JTextArea t=new JTextArea(10,10);
					t.setFont(new Font("Serif",Font.BOLD,16));//�����ı�����
					t.setLineWrap(true);//�����Զ����й���
					t.setWrapStyleWord(true);//������в����ֹ���
					t.setEditable(false);//��t2��Ϊ���ɱ༭��������ֻ�ܰ�����Ӧ��ʾ���ܼ�������
					t.setBorder(new LineBorder(Color.pink,10));
					t.setText(all);
					 JPanel p1=new JPanel(new GridLayout(1,2,10,10));
					
				 JButton trolley=new JButton("���빺�ﳵ");
				  trolley.addActionListener(new ActionListener(){

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
					
					String amount=JOptionPane.showInputDialog("��Ҫ�������������������ڵ���1����������");
						m1.addPet(information.get(a).get("name"),information.get(a).get("price"),amount);
						 JOptionPane.showMessageDialog(null, "����ɹ�");
						
							
						
					}
					  
				  });
					   p1.add(trolley);
					   JButton back=new JButton("����");
				       back.addActionListener(new Respondb());
					  p1.add(back);
					frame1.add(title,BorderLayout.NORTH);
					frame1.add(new JScrollPane(t),BorderLayout.CENTER);
					frame1.add(p1, BorderLayout.SOUTH);
				     frame1.setVisible(true);
				     frame.dispose();
				     
					}
				});
			showPetPanel.add(b[i]);//����������Ӱ�ť
		}
		 JButton myTrolley=new JButton("�鿴�ҵĹ��ﳵ");
			myTrolley.addActionListener(new Respondm());
	frame.add(showPetPanel,BorderLayout.CENTER);
	frame.add(myTrolley,BorderLayout.SOUTH);
    frame.setBackground(Color.pink);
	
	  frame.setVisible(true);
}

class Respondm implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	m1.showMyTrolley();
	frame.dispose();

	
	}
	
}


class Respondb implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	ShowPetPanel s=new ShowPetPanel();
	try {
		s.creatPetNameFrame();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}

	frame1.dispose();
	}
	
}

}
