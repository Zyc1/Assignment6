import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class RegisterPanel {
	JFrame frame = new JFrame();
	JTextArea account;
	 JTextArea password1;
	 JTextArea password2;
public  void creatRegisterFrame(){
	
	frame.setTitle("Register");
     frame.setBounds(100,100,400,500);
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
	JPanel registerPanel=new JPanel();
	registerPanel.setLayout(null);
    JLabel account_register=new JLabel("�˺�:");
	account_register.setBounds(110,100,30,20);
	registerPanel.add(account_register);
	account=new JTextArea();
	account.setLineWrap(true);
	JScrollPane account2 = new JScrollPane(account);
	account2.setBounds(160, 100, 130, 20);
	registerPanel.add(account2);
	
	JLabel password_register=new JLabel("����:");
	password_register.setBounds(110,160, 30, 20);
	registerPanel.add(password_register);
    password1=new JTextArea();
	password1.setLineWrap(true);
	JScrollPane password11 = new JScrollPane(password1);
	password11.setBounds(160, 160, 130, 20);
	registerPanel.add(password11);
	
	
	JLabel password_again=new JLabel("ȷ������:");
	password_again.setBounds(90,220, 70, 20);
	registerPanel.add(password_again);
	  password2=new JTextArea();
		password2.setLineWrap(true);
		JScrollPane password22 = new JScrollPane(password2);
		password22.setBounds(160, 220, 130, 20);
		registerPanel.add(password22);
	
	
	  JButton ensure=new JButton("ȷ��");
	   ensure.setBounds(110, 300, 60, 20);
	   ensure.addActionListener(new Responde());
	   registerPanel.add(ensure);
	   
	   
	   JButton back=new JButton("����");
	   back.setBounds(225, 300, 60, 20);
	   back.addActionListener(new Respondb());
	   registerPanel.add(back);
	 registerPanel.setBackground(Color.pink);
	 frame.setContentPane(registerPanel);
	  frame.setVisible(true);
	
}

class Responde implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Match m=new Match();
		int isHas=0;
		 try {
		 isHas=m.matchAccount(account.getText());
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	if(isHas==1)
		 JOptionPane.showMessageDialog(null, "���˻��ѱ�ע��");
	else if(account.getText().isEmpty()||password1.getText().isEmpty()||password2.getText().isEmpty())
			 JOptionPane.showMessageDialog(null, "�뽫��Ϣ��д����");
		
    else
			{
			if(password1.getText().equals(password2.getText()))
				
			{
				
				try {
					m.addUser(account.getText(), password1.getText());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 JOptionPane.showMessageDialog(null, "ע��ɹ�");
			}
			else
				 JOptionPane.showMessageDialog(null, "�����������벻һ��");
			}
}
}
class Respondb implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	GUI g=new GUI();
	g.creatStartGUI();
	frame.dispose();
	}
	
}
}























